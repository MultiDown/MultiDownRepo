# -*- coding: utf-8 -*-
import multidown,plugintools,urllib,xbmcplugin,xbmc,xbmcgui,urlresolver
import logging,xbmcaddon
__settings__ = xbmcaddon.Addon(id='plugin.video.multidown')
__PLUGIN_PATH__ = __settings__.getAddonInfo('path')
def get_menu():
    
    thumbnail=__PLUGIN_PATH__ + "\\resources\\fanart.png"  
    fanart=__PLUGIN_PATH__ + "\\resources\\fanart.png"
    plugintools.add_item(title=u'[COLOR blue]חיפוש[/COLOR]',action='search',thumbnail=thumbnail,fanart=fanart)
    menu_list = multidown.getCategories()
    for cat in menu_list:
        fanart=''
        thumbnail=''
        if (cat.get('title').encode('utf-8'))=="פעולה":
          thumbnail=__PLUGIN_PATH__ + "\\resources\\Action.png"
          fanart=__PLUGIN_PATH__ + "\\resources\\fanart.png"
        elif (cat.get('title').encode('utf-8'))=="הרפתקאות":
          thumbnail=__PLUGIN_PATH__ + "\\resources\\Adventure.png"
          fanart=__PLUGIN_PATH__ + "\\resources\\fanart.png"
        elif (cat.get('title').encode('utf-8'))=="אנימציה":
          thumbnail=__PLUGIN_PATH__ + "\\resources\\Animation.png"
          fanart=__PLUGIN_PATH__ + "\\resources\\fanart.png"
        elif (cat.get('title').encode('utf-8'))=="ביוגרפיה":
          thumbnail=__PLUGIN_PATH__ + "\\resources\\Biography.png"
          fanart=__PLUGIN_PATH__ + "\\resources\\fanart.png"
        elif (cat.get('title').encode('utf-8'))=="קומדיה":
          thumbnail=__PLUGIN_PATH__ + "\\resources\\Comedy.png"
          fanart=__PLUGIN_PATH__ + "\\resources\\fanart.png"
        elif (cat.get('title').encode('utf-8'))=="פשע":
          thumbnail=__PLUGIN_PATH__ + "\\resources\\Crime.png"
          fanart=__PLUGIN_PATH__ + "\\resources\\fanart.png"
        elif (cat.get('title').encode('utf-8'))=="דוקומנטרי":
          thumbnail=__PLUGIN_PATH__ + "\\resources\\Documentary.png"
          fanart=__PLUGIN_PATH__ + "\\resources\\fanart.png"
        elif (cat.get('title').encode('utf-8'))=="דרמה":
          thumbnail=__PLUGIN_PATH__ + "\\resources\\Drama.png"
          fanart=__PLUGIN_PATH__ + "\\resources\\fanart.png"
        elif (cat.get('title').encode('utf-8'))=="משפחה":
          thumbnail=__PLUGIN_PATH__ + "\\resources\\Family.png"
          fanart=__PLUGIN_PATH__ + "\\resources\\fanart.png"
        elif (cat.get('title').encode('utf-8'))=="פנטזיה":
          thumbnail=__PLUGIN_PATH__ + "\\resources\\Fantasy.png"
          fanart=__PLUGIN_PATH__ + "\\resources\\fanart.png"
        elif (cat.get('title').encode('utf-8'))=="היסטוריה":
          thumbnail=__PLUGIN_PATH__ + "\\resources\\History.png"
          fanart=__PLUGIN_PATH__ + "\\resources\\fanart.png"
        elif (cat.get('title').encode('utf-8'))=="אימה":
          thumbnail=__PLUGIN_PATH__ + "\\resources\\Horror.png"
          fanart=__PLUGIN_PATH__ + "\\resources\\fanart.png"
        elif (cat.get('title').encode('utf-8'))=="מוזיקה":
          thumbnail=__PLUGIN_PATH__ + "\\resources\\Musical.png"
          fanart=__PLUGIN_PATH__ + "\\resources\\fanart.png"
        elif (cat.get('title').encode('utf-8'))=="מסתורין":
          thumbnail=__PLUGIN_PATH__ + "\\resources\\Mystery.png"
          fanart=__PLUGIN_PATH__ + "\\resources\\fanart.png"
        elif (cat.get('title').encode('utf-8'))=="רומנטיקה":
          thumbnail=__PLUGIN_PATH__ + "\\resources\\Romance.png"
          fanart=__PLUGIN_PATH__ + "\\resources\\fanart.png"
        elif (cat.get('title').encode('utf-8'))=="מדע בדיוני":
          thumbnail=__PLUGIN_PATH__ + "\\resources\\Sci-fi.png"
          fanart=__PLUGIN_PATH__ + "\\resources\\fanart.png"
        elif (cat.get('title').encode('utf-8'))=="מתח":
          thumbnail=__PLUGIN_PATH__ + "\\resources\\Thriller.png"
          fanart=__PLUGIN_PATH__ + "\\resources\\fanart.png"
        elif (cat.get('title').encode('utf-8'))=="מלחמה":
          thumbnail=__PLUGIN_PATH__ + "\\resources\\War.png"
          fanart=__PLUGIN_PATH__ + "\\resources\\fanart.png"
        elif (cat.get('title').encode('utf-8'))=="מערבון":
          thumbnail=__PLUGIN_PATH__ + "\\resources\\Western.png"
          fanart=__PLUGIN_PATH__ + "\\resources\\fanart.png"
        elif (cat.get('title').encode('utf-8'))=="מדובב":
          thumbnail=__PLUGIN_PATH__ + "\\resources\\HebDub.png"
          fanart=__PLUGIN_PATH__ + "\\resources\\fanart.png"		  
        elif (cat.get('title').encode('utf-8'))=="ישראלי":
          thumbnail=__PLUGIN_PATH__ + "\\resources\\Israeli.png"
          fanart=__PLUGIN_PATH__ + "\\resources\\fanart.png"
        else:
          thumbnail=__PLUGIN_PATH__ + "\\resources\\fanart.png"
          fanart=__PLUGIN_PATH__ + "\\resources\\fanart.png"
        plugintools.add_item(title=cat.get('title'),action='showposts',url=cat.get('url'),thumbnail=thumbnail,fanart=fanart)
    plugintools.close_item_list()
    
def search():
    print "yuval"
    searchtext=""
    keyboard = xbmc.Keyboard(searchtext,u'הכנס שם של סדרה/סרט')
    keyboard.doModal()
    if (keyboard.isConfirmed()):
        get_posts('http://www.multidown.me/?s='+keyboard.getText().replace(' ','+'))
        
def get_posts(url):
    postsList = multidown.getPosts(url)
    for post in postsList:
        if u'עמוד הבא' not in post.get('title'):
            title = post.get('title')
            if u'*היידפנישן*' in title:
                title = '[COLOR red]HD[/COLOR] ' + title.replace(u'*היידפנישן*','')
            plugintools.add_item(title=title,action='showsources',url=post.get('url'),thumbnail=post.get('thumbnail'),plot=post.get('plot'),itemcount=len(postsList),extra=post.get('title'))
        else:
            plugintools.add_item(title='[COLOR red]'+post.get('title')+'[/COLOR]',action='showposts',url=post.get('url'))
    plugintools.close_item_list()
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    xbmc.executebuiltin("Container.SetViewMode(500)")

def get_sources(url,extra,thumb):
    sourcesList = multidown.getSources(url)
    for source in sourcesList:
        plugintools.add_item(title=source.get('title'),action='stream',url=source.get('url'),extra=extra,thumbnail=thumb)
    plugintools.close_item_list()
    
def resolveUrls(url,extra,thumb):
    #if 'openload' not in url:
    # url = url.lower()
    url=url.replace('/v/',"/embed/")
    url=url.replace('/f/',"/embed/")

    if 'myfile' in url:

        resolved_url = multidown.myfile(url)
    else:
        final=urlresolver.HostedMediaFile(url)
        new_url=final.get_url()
    
        resolved_url=urlresolver.resolve(new_url)
    stream(resolved_url,extra,thumb)
        
def stream(url,title,thumbnail):
    path=url
    li = xbmcgui.ListItem(label=title, iconImage=thumbnail, thumbnailImage=thumbnail,path=path)
    li.setInfo(type='Video', infoLabels={ "Title": str(title) })
    xbmc.Player().play(path,li)
    
def run():
    params = plugintools.get_params()
    action = params.get('action')
    if action == None:
        get_menu()
    elif action == 'search':
        search()
    elif action == 'showposts':
        get_posts(params.get('url'))
    elif action == 'showsources':
        get_sources(params.get('url'),urllib.unquote_plus(params.get('extra')).decode('utf-8'),params.get('thumbnail'))
    elif action == 'stream':
        resolveUrls(params.get('url'),urllib.unquote_plus(params.get('extra')),params.get('thumbnail'))
    
run()
